// src/components/Header.tsx
export default function Header() {
    return <header>Meu cabeçalho</header>
  }