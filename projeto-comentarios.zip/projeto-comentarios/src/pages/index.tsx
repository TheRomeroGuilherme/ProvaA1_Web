export default function AboutPage() {
    return <div>Sobre nós</div>
  }